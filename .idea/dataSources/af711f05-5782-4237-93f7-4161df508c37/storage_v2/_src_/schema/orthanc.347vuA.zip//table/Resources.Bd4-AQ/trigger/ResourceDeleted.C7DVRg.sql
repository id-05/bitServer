create definer = orthanc@`%` trigger ResourceDeleted
    before delete
    on Resources
    for each row
BEGIN
   INSERT INTO DeletedFiles SELECT uuid, fileType, compressedSize, uncompressedSize, compressionType, uncompressedHash, compressedHash FROM AttachedFiles WHERE id=old.internalId;
END;

