create definer = orthanc@`%` trigger AttachedFileDeleted
    after delete
    on AttachedFiles
    for each row
BEGIN
  INSERT INTO DeletedFiles VALUES(old.uuid, old.filetype, old.compressedSize,
                                  old.uncompressedSize, old.compressionType,
                                  old.uncompressedHash, old.compressedHash);
END;

