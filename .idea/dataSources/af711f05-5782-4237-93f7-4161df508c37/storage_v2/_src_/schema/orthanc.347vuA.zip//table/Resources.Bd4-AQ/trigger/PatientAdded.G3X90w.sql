create definer = orthanc@`%` trigger PatientAdded
    after insert
    on Resources
    for each row
BEGIN
  IF new.resourceType = 0 THEN  -- The "0" corresponds to "OrthancPluginResourceType_Patient"
    INSERT INTO PatientRecyclingOrder VALUES (NULL, new.internalId);
  END IF;
END;

