create definer = orthanc@`%` trigger ChangeAdded
    after insert
    on Changes
    for each row
BEGIN
  UPDATE GlobalIntegers SET value = new.seq WHERE property = 0;
END;

